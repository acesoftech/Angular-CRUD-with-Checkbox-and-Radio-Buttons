export class Students{

    id?: number;  
    first_name?: string;  
    last_name?: string;  
    email?: string;  
    passwod?: string; 
    gender?: string;
    hobbies?:string
    country?:string
    
}